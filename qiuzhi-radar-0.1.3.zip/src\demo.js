const resumeText = document.querySelector("#resumeText");
const resumePdf = document.querySelector("#resumePdf");
const fileStatus = document.querySelector("#fileStatus");
const saveBtn = document.querySelector("#saveBtn");
const clearBtn = document.querySelector("#clearBtn");
const refreshBtn = document.querySelector("#refreshBtn");
const scoreValue = document.querySelector("#scoreValue");
const scoreLabel = document.querySelector("#scoreLabel");
const scoreReason = document.querySelector("#scoreReason");
const matchedList = document.querySelector("#matchedList");
const missingList = document.querySelector("#missingList");
const jobKeywords = document.querySelector("#jobKeywords");
const resumeKeywords = document.querySelector("#resumeKeywords");
const demoJob = document.querySelector("#demoJob");

saveBtn.addEventListener("click", analyze);
refreshBtn.addEventListener("click", analyze);
clearBtn.addEventListener("click", () => {
  resumeText.value = "";
  resumePdf.value = "";
  fileStatus.textContent = "也可以直接粘贴文本";
  renderEmpty("等待简历", "粘贴简历后，会基于当前招聘页面做本地匹配分析。");
});

resumePdf.addEventListener("change", async () => {
  const file = resumePdf.files?.[0];
  if (!file) return;

  fileStatus.textContent = `正在读取：${file.name}`;
  saveBtn.disabled = true;
  refreshBtn.disabled = true;
  try {
    const text = await extractTextFromPdf(file);
    resumeText.value = text;
    fileStatus.textContent = `已读取：${file.name}`;
    analyze();
  } catch (error) {
    fileStatus.textContent = "PDF 读取失败";
    scoreReason.textContent = error.message || "这个 PDF 可能是扫描件或受保护文件。";
  } finally {
    saveBtn.disabled = false;
    refreshBtn.disabled = false;
  }
});

analyze();

function analyze() {
  const resume = resumeText.value.trim();
  if (!resume) {
    renderEmpty("等待简历", "粘贴简历后，会基于当前招聘页面做本地匹配分析。");
    return;
  }

  renderResult(ResumeMatcher.matchResumeToJob(resume, demoJob.innerText));
}

async function extractTextFromPdf(file) {
  const pdfjsLib = await import("../vendor/pdf.mjs");
  pdfjsLib.GlobalWorkerOptions.workerSrc = "../vendor/pdf.worker.mjs";

  const data = new Uint8Array(await file.arrayBuffer());
  const pdf = await pdfjsLib.getDocument({ data }).promise;
  const pages = [];

  for (let pageNumber = 1; pageNumber <= pdf.numPages; pageNumber += 1) {
    const page = await pdf.getPage(pageNumber);
    const content = await page.getTextContent();
    const pageText = content.items
      .map((item) => item.str || "")
      .join(" ")
      .replace(/\s+/g, " ")
      .trim();
    if (pageText) pages.push(pageText);
  }

  const text = pages.join("\n\n").trim();
  if (!text) {
    throw new Error("没有从 PDF 中识别到文字。扫描版 PDF 需要 OCR。");
  }
  return text;
}

function renderResult(result) {
  document.documentElement.style.setProperty("--score", `${result.score}%`);
  scoreValue.textContent = result.score;

  if (result.score >= 75) {
    scoreLabel.textContent = "匹配度较高";
    scoreReason.textContent = "你的简历覆盖了当前岗位的大部分核心关键词。";
  } else if (result.score >= 45) {
    scoreLabel.textContent = "可以尝试";
    scoreReason.textContent = "存在部分匹配项，建议补充岗位要求中的关键经验。";
  } else {
    scoreLabel.textContent = "匹配偏低";
    scoreReason.textContent = "当前页面的核心要求在简历中覆盖较少。";
  }

  renderList(matchedList, result.matched, "暂未发现明确匹配项");
  renderList(missingList, result.missing, "暂未识别出明显缺口");
  jobKeywords.textContent = result.jobTerms.join("、") || "--";
  resumeKeywords.textContent = result.resumeTerms.join("、") || "--";
}

function renderEmpty(label, reason) {
  document.documentElement.style.setProperty("--score", "0%");
  scoreValue.textContent = "--";
  scoreLabel.textContent = label;
  scoreReason.textContent = reason;
  renderList(matchedList, [], "暂无数据");
  renderList(missingList, [], "暂无数据");
  jobKeywords.textContent = "--";
  resumeKeywords.textContent = "--";
}

function renderList(container, items, emptyText) {
  container.replaceChildren();
  const values = items.length ? items : [emptyText];
  for (const value of values) {
    const li = document.createElement("li");
    li.textContent = value;
    container.append(li);
  }
}
