function visibleTextFromPage() {
  const selectorsToSkip = ["script", "style", "noscript", "svg", "canvas", "iframe", "nav", "footer"];
  const clone = document.body ? document.body.cloneNode(true) : document.documentElement.cloneNode(true);
  clone.querySelectorAll(selectorsToSkip.join(",")).forEach((node) => node.remove());

  const title = document.title || "";
  const headings = Array.from(document.querySelectorAll("h1,h2,h3"))
    .map((node) => cleanText(node.innerText))
    .filter(Boolean)
    .slice(0, 12)
    .join("\n");

  return [title, headings, clone.innerText || ""]
    .join("\n")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 60000);
}

function cleanText(text) {
  return String(text || "")
    .replace(/\s+/g, " ")
    .trim();
}

const salaryPattern =
  /(?:\d+(?:\.\d+)?\s*-\s*\d+(?:\.\d+)?\s*[kK](?:·\d+薪)?|\d+\s*-\s*\d+\s*元\/天|\d+\s*-\s*\d+\s*元\/月|\d+(?:\.\d+)?万\s*-\s*\d+(?:\.\d+)?万|面议)/;

const jobSignalPattern =
  /招聘|岗位|职位|经验|本科|大专|硕士|实习|工程师|开发|前端|后端|全栈|算法|测试|产品|运营|设计|策划|数据|Java|Python|React|Vue|Node|Go|C\+\+/;

function looksLikeJobCard(text) {
  if (!text || text.length < 18 || text.length > 2200) return false;
  if (/登录|注册|隐私政策|用户协议|帮助中心/.test(text) && text.length < 120) return false;
  return salaryPattern.test(text) || jobSignalPattern.test(text);
}

function pickTitle(card, text) {
  const titleNode = card.querySelector(
    ".job-name,.job-title,.name,.position-name,.position-title,[class*='job-name'],[class*='job-title'],[class*='position'],h1,h2,h3,a"
  );
  const raw = cleanText(titleNode?.innerText || titleNode?.textContent || "");
  if (raw && raw.length <= 80) return raw;

  const lines = (card.innerText || "")
    .split(/\n+/)
    .map(cleanText)
    .filter(Boolean);
  const titleLine = lines.find((line) => line.length >= 2 && line.length <= 40 && !salaryPattern.test(line));
  return titleLine || text.slice(0, 40);
}

function pickCompany(card) {
  const companyNode = card.querySelector(
    ".company-name,.company,.brand-name,.boss-name,[class*='company'],[class*='brand']"
  );
  const raw = cleanText(companyNode?.innerText || companyNode?.textContent || "");
  if (raw && raw.length <= 80) return raw;

  const lines = (card.innerText || "")
    .split(/\n+/)
    .map(cleanText)
    .filter(Boolean);
  return lines.find((line) => /公司|科技|网络|游戏|软件|智能|数据|教育|集团|有限/.test(line) && line.length <= 60) || "";
}

function parseJobCard(card, index) {
  const text = cleanText(card.innerText || card.textContent || "");
  if (!looksLikeJobCard(text)) return null;

  const link = card.querySelector("a[href]");
  const salaryMatch = text.match(salaryPattern);
  return {
    id: `${location.hostname}:${index}:${text.slice(0, 100)}`,
    title: pickTitle(card, text),
    company: pickCompany(card),
    salary: salaryMatch ? salaryMatch[0].replace(/\s+/g, "") : "",
    url: link ? new URL(link.getAttribute("href"), location.href).href : location.href,
    source: location.hostname,
    text
  };
}

function bossCardCandidates() {
  const selectors = [
    ".job-card-wrapper",
    ".job-card-box",
    ".job-card-body",
    ".job-primary",
    ".job-list-box li",
    ".search-job-result li",
    "[class*='job-card']",
    "[class*='jobCard']",
    "[class*='job-list'] li",
    "[class*='position-card']"
  ];

  const nodes = [];
  for (const selector of selectors) {
    document.querySelectorAll(selector).forEach((node) => nodes.push(node));
  }
  return nodes;
}

function salaryBasedCandidates() {
  const candidates = [];
  const elements = Array.from(document.querySelectorAll("li,article,section,div"));

  for (const element of elements) {
    const text = cleanText(element.innerText || element.textContent || "");
    if (!salaryPattern.test(text) || !jobSignalPattern.test(text)) continue;
    if (text.length < 18 || text.length > 2200) continue;

    const childrenWithSalary = Array.from(element.children).filter((child) =>
      salaryPattern.test(cleanText(child.innerText || child.textContent || ""))
    );
    if (childrenWithSalary.length > 1 && text.length > 500) continue;

    candidates.push(element);
  }

  return candidates;
}

function visibleJobsFromPage() {
  const nodes = [...bossCardCandidates(), ...salaryBasedCandidates()];
  const seenNodes = new Set();
  const seenJobs = new Set();
  const jobs = [];

  for (const node of nodes) {
    if (seenNodes.has(node)) continue;
    seenNodes.add(node);

    const job = parseJobCard(node, jobs.length);
    if (!job) continue;

    const fingerprint = `${job.title}|${job.company}|${job.salary}|${job.text.slice(0, 160)}`;
    if (seenJobs.has(fingerprint)) continue;
    seenJobs.add(fingerprint);
    jobs.push(job);
    if (jobs.length >= 80) break;
  }

  if (!jobs.length) {
    const pageText = visibleTextFromPage();
    if (looksLikeJobCard(pageText)) {
      jobs.push({
        id: `${location.hostname}:page:${location.pathname}`,
        title: document.title || "当前岗位页面",
        company: location.hostname,
        salary: (pageText.match(salaryPattern) || [""])[0],
        url: location.href,
        source: location.hostname,
        text: pageText
      });
    }
  }

  return jobs;
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "GET_VISIBLE_JOBS") {
    sendResponse({
      title: document.title || location.hostname,
      url: location.href,
      jobs: visibleJobsFromPage()
    });
    return;
  }

  if (message?.type !== "GET_JOB_PAGE_TEXT") return;

  sendResponse({
    title: document.title || location.hostname,
    url: location.href,
    text: visibleTextFromPage()
  });
});
