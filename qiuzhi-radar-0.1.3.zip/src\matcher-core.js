(function attachMatcherCore(global) {
  const keywordGroups = [
    ["JavaScript", "javascript", "js", "前端"],
    ["TypeScript", "typescript", "ts"],
    ["React", "react", "next.js", "nextjs"],
    ["Vue", "vue", "nuxt"],
    ["Node.js", "node.js", "nodejs", "express", "koa", "nestjs"],
    ["Python", "python", "django", "flask", "fastapi"],
    ["Java", "java", "spring", "springboot", "spring boot"],
    ["Go", "golang", "go语言"],
    ["C++", "c++", "cpp"],
    ["SQL", "sql", "mysql", "postgresql", "postgres", "oracle"],
    ["Redis", "redis"],
    ["Docker", "docker", "容器"],
    ["Kubernetes", "kubernetes", "k8s"],
    ["AWS", "aws", "amazon web services"],
    ["Azure", "azure"],
    ["GCP", "gcp", "google cloud"],
    ["Linux", "linux"],
    ["Git", "git"],
    ["CI/CD", "ci/cd", "cicd", "jenkins", "github actions", "gitlab ci"],
    ["测试", "测试", "test", "testing", "自动化测试", "unit test"],
    ["数据分析", "数据分析", "analytics", "tableau", "power bi"],
    ["机器学习", "机器学习", "machine learning", "ml", "深度学习", "模型"],
    ["产品", "产品经理", "prd", "需求分析", "用户研究"],
    ["运营", "运营", "增长", "活动策划"],
    ["项目管理", "项目管理", "敏捷", "scrum", "jira"],
    ["沟通协作", "沟通", "协作", "跨部门", "stakeholder"],
    ["英语", "英语", "english", "cet", "ielts", "toefl"]
  ];

  const stopWords = new Set([
    "the",
    "and",
    "for",
    "with",
    "you",
    "are",
    "our",
    "your",
    "岗位",
    "职位",
    "要求",
    "负责",
    "优先",
    "工作",
    "能力",
    "相关",
    "经验",
    "公司",
    "招聘"
  ]);

  function matchResumeToJob(resume, jobText) {
    const resumeLower = normalize(resume);
    const jobLower = normalize(jobText);
    const resumeSkillSet = detectSkills(resumeLower);
    const jobSkillSet = detectSkills(jobLower);
    const extractedJobTerms = extractTerms(jobLower, 18);
    const extractedResumeTerms = extractTerms(resumeLower, 18);

    const matchedSkills = [...jobSkillSet].filter((skill) => resumeSkillSet.has(skill));
    const missingSkills = [...jobSkillSet].filter((skill) => !resumeSkillSet.has(skill));
    const termOverlap = extractedJobTerms.filter((term) => extractedResumeTerms.includes(term));

    const skillScore = jobSkillSet.size
      ? matchedSkills.length / jobSkillSet.size
      : jaccard(extractedResumeTerms, extractedJobTerms);
    const coverageScore = extractedJobTerms.length
      ? termOverlap.length / Math.min(extractedJobTerms.length, 12)
      : 0;
    const lengthConfidence = Math.min(String(resume || "").length / 1200, 1);
    const score = Math.round((skillScore * 72 + coverageScore * 20 + lengthConfidence * 8) * 100) / 100;
    const boundedScore = Math.max(0, Math.min(98, Math.round(score)));

    return {
      score: boundedScore,
      matched: matchedSkills.length ? matchedSkills : termOverlap.slice(0, 8),
      missing: missingSkills.slice(0, 8),
      jobTerms: [...jobSkillSet, ...extractedJobTerms].slice(0, 16),
      resumeTerms: [...resumeSkillSet, ...extractedResumeTerms].slice(0, 16)
    };
  }

  function rankJobWithResumes(job, resumes) {
    const versions = resumes
      .filter((resume) => resume?.text?.trim())
      .map((resume) => {
        const result = matchResumeToJob(resume.text, job.text || "");
        return {
          resumeId: resume.id,
          resumeName: resume.name || "未命名简历",
          score: result.score,
          matched: result.matched,
          missing: result.missing,
          jobTerms: result.jobTerms,
          resumeTerms: result.resumeTerms
        };
      })
      .sort((a, b) => b.score - a.score);

    return {
      ...job,
      best: versions[0] || null,
      versions
    };
  }

  function rankJobs(jobs, resumes) {
    return jobs
      .map((job) => rankJobWithResumes(job, resumes))
      .sort((a, b) => (b.best?.score || 0) - (a.best?.score || 0));
  }

  function detectSkills(text) {
    const found = new Set();
    for (const [label, ...aliases] of keywordGroups) {
      const terms = [label, ...aliases].map(normalize);
      if (terms.some((term) => text.includes(term))) found.add(label);
    }
    return found;
  }

  function extractTerms(text, limit) {
    const tokens = text.match(/[a-zA-Z][a-zA-Z0-9+#./-]{1,}|[\u4e00-\u9fa5]{2,}/g) || [];
    const counts = new Map();

    for (const token of tokens) {
      const normalized = token.toLowerCase();
      if (stopWords.has(normalized) || normalized.length < 2) continue;
      counts.set(normalized, (counts.get(normalized) || 0) + 1);
    }

    return [...counts.entries()]
      .sort((a, b) => b[1] - a[1])
      .slice(0, limit)
      .map(([term]) => term);
  }

  function normalize(text) {
    return String(text || "")
      .toLowerCase()
      .replace(/\s+/g, " ")
      .trim();
  }

  function jaccard(a, b) {
    const setA = new Set(a);
    const setB = new Set(b);
    const intersection = [...setA].filter((value) => setB.has(value)).length;
    const union = new Set([...setA, ...setB]).size;
    return union ? intersection / union : 0;
  }

  global.ResumeMatcher = { matchResumeToJob, rankJobWithResumes, rankJobs };
})(globalThis);
