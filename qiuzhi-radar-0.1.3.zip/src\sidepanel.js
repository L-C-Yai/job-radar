const STORAGE_KEYS = {
  resumes: "resumeVersions",
  jobs: "collectedJobs"
};

const pageTitle = document.querySelector("#pageTitle");
const refreshBtn = document.querySelector("#refreshBtn");
const scanBtn = document.querySelector("#scanBtn");
const clearJobsBtn = document.querySelector("#clearJobsBtn");
const jobCount = document.querySelector("#jobCount");
const resumeCount = document.querySelector("#resumeCount");
const topScore = document.querySelector("#topScore");
const scanStatus = document.querySelector("#scanStatus");
const jobSearch = document.querySelector("#jobSearch");
const clearSearchBtn = document.querySelector("#clearSearchBtn");
const rankedJobs = document.querySelector("#rankedJobs");
const resumeList = document.querySelector("#resumeList");
const resumeName = document.querySelector("#resumeName");
const resumePdf = document.querySelector("#resumePdf");
const resumeText = document.querySelector("#resumeText");
const fileStatus = document.querySelector("#fileStatus");
const saveResumeBtn = document.querySelector("#saveResumeBtn");

let resumes = [];
let jobs = [];

init();

refreshBtn.addEventListener("click", refreshPageInfo);
scanBtn.addEventListener("click", scanCurrentPage);
clearJobsBtn.addEventListener("click", async () => {
  jobs = [];
  await chrome.storage.local.set({ [STORAGE_KEYS.jobs]: jobs });
  scanStatus.textContent = "岗位库已清空";
  render();
});

jobSearch.addEventListener("input", render);
clearSearchBtn.addEventListener("click", () => {
  jobSearch.value = "";
  render();
});

saveResumeBtn.addEventListener("click", saveResumeVersion);
resumePdf.addEventListener("change", readResumePdf);

async function init() {
  const stored = await chrome.storage.local.get([STORAGE_KEYS.resumes, STORAGE_KEYS.jobs, "resume"]);
  resumes = Array.isArray(stored[STORAGE_KEYS.resumes]) ? stored[STORAGE_KEYS.resumes] : [];
  jobs = Array.isArray(stored[STORAGE_KEYS.jobs]) ? stored[STORAGE_KEYS.jobs] : [];

  if (!resumes.length && stored.resume) {
    resumes = [
      {
        id: crypto.randomUUID(),
        name: "默认简历",
        text: stored.resume,
        createdAt: Date.now()
      }
    ];
    await chrome.storage.local.set({ [STORAGE_KEYS.resumes]: resumes });
  }

  await refreshPageInfo();
  render();
}

async function refreshPageInfo() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    pageTitle.textContent = tab?.title || tab?.url || "当前页面";
  } catch {
    pageTitle.textContent = "当前页面";
  }
}

async function scanCurrentPage() {
  setBusy(true);
  scanStatus.textContent = "正在扫描当前页面...";
  try {
    const page = await getVisibleJobsFromCurrentTab();
    pageTitle.textContent = page.title || page.url || "当前页面";
    const before = jobs.length;
    jobs = mergeJobs(jobs, page.jobs || []);
    await chrome.storage.local.set({ [STORAGE_KEYS.jobs]: jobs });
    scanStatus.textContent = `新增 ${jobs.length - before} 个岗位，当前共 ${jobs.length} 个`;
    render();
  } catch (error) {
    scanStatus.textContent = error.message || "扫描失败，请刷新招聘页面后重试";
  } finally {
    setBusy(false);
  }
}

async function getVisibleJobsFromCurrentTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) throw new Error("没有找到当前标签页");

  try {
    return await chrome.tabs.sendMessage(tab.id, { type: "GET_VISIBLE_JOBS" });
  } catch {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["src/content.js"]
    });
    return chrome.tabs.sendMessage(tab.id, { type: "GET_VISIBLE_JOBS" });
  }
}

async function saveResumeVersion() {
  const name = resumeName.value.trim();
  const text = resumeText.value.trim();
  if (!text) {
    fileStatus.textContent = "请先选择 PDF 或粘贴简历文本";
    return;
  }

  resumes = [
    {
      id: crypto.randomUUID(),
      name: name || `简历版本 ${resumes.length + 1}`,
      text,
      createdAt: Date.now()
    },
    ...resumes
  ];

  await chrome.storage.local.set({ [STORAGE_KEYS.resumes]: resumes });
  resumeName.value = "";
  resumePdf.value = "";
  resumeText.value = "";
  fileStatus.textContent = "已保存简历版本";
  render();
}

async function readResumePdf() {
  const file = resumePdf.files?.[0];
  if (!file) return;
  if (file.type && file.type !== "application/pdf") {
    fileStatus.textContent = "请选择 PDF 文件";
    return;
  }

  setBusy(true);
  fileStatus.textContent = `正在读取：${file.name}`;
  try {
    resumeText.value = await extractTextFromPdf(file);
    if (!resumeName.value.trim()) resumeName.value = file.name.replace(/\.pdf$/i, "");
    fileStatus.textContent = `已读取：${file.name}`;
  } catch (error) {
    fileStatus.textContent = error.message || "PDF 读取失败";
  } finally {
    setBusy(false);
  }
}

async function extractTextFromPdf(file) {
  const pdfjsLib = await import(chrome.runtime.getURL("vendor/pdf.mjs"));
  pdfjsLib.GlobalWorkerOptions.workerSrc = chrome.runtime.getURL("vendor/pdf.worker.mjs");

  const data = new Uint8Array(await file.arrayBuffer());
  const pdf = await pdfjsLib.getDocument({ data }).promise;
  const pages = [];

  for (let pageNumber = 1; pageNumber <= pdf.numPages; pageNumber += 1) {
    const page = await pdf.getPage(pageNumber);
    const content = await page.getTextContent();
    const pageText = content.items
      .map((item) => item.str || "")
      .join(" ")
      .replace(/\s+/g, " ")
      .trim();
    if (pageText) pages.push(pageText);
  }

  const text = pages.join("\n\n").trim();
  if (!text) throw new Error("未从 PDF 中识别到文字，扫描版 PDF 需要 OCR");
  return text;
}

function mergeJobs(existing, incoming) {
  const map = new Map();
  for (const job of existing) {
    map.set(jobKey(job), job);
  }
  for (const job of incoming) {
    const normalized = {
      ...job,
      id: job.id || crypto.randomUUID(),
      collectedAt: Date.now()
    };
    const key = jobKey(normalized);
    if (!map.has(key)) map.set(key, normalized);
  }
  return [...map.values()];
}

function jobKey(job) {
  return [
    job.url || "",
    job.title || "",
    job.company || "",
    String(job.text || "").slice(0, 120)
  ].join("|");
}

function render() {
  const filteredJobs = filterJobs(jobs, jobSearch.value);
  const ranked = ResumeMatcher.rankJobs(filteredJobs, resumes);

  jobCount.textContent = jobSearch.value.trim() ? `${filteredJobs.length}/${jobs.length}` : jobs.length;
  resumeCount.textContent = resumes.length;
  topScore.textContent = ranked[0]?.best ? ranked[0].best.score : "--";

  renderJobs(ranked);
  renderResumes();
}

function filterJobs(sourceJobs, query) {
  const terms = normalize(query)
    .split(/\s+/)
    .filter(Boolean);
  if (!terms.length) return sourceJobs;

  return sourceJobs.filter((job) => {
    const searchable = normalize([
      job.title,
      job.company,
      job.salary,
      job.source,
      job.text
    ].join(" "));
    return terms.every((term) => searchable.includes(term));
  });
}

function renderJobs(ranked) {
  rankedJobs.replaceChildren();
  if (!resumes.length) {
    rankedJobs.append(emptyNode("先在下方添加至少一个简历版本"));
    return;
  }
  if (!jobs.length) {
    rankedJobs.append(emptyNode("打开招聘搜索结果页后，点击“扫描当前页面岗位”"));
    return;
  }
  if (!ranked.length) {
    rankedJobs.append(emptyNode("没有匹配当前搜索词的岗位"));
    return;
  }

  for (const [index, job] of ranked.entries()) {
    const card = document.createElement("article");
    card.className = "job-card";

    const best = job.best;
    const meta = [job.company, job.salary, job.source].filter(Boolean).join(" · ");
    const matched = best?.matched?.slice(0, 5).join("、") || "暂无明显命中";
    const missing = best?.missing?.slice(0, 4).join("、") || "暂无明显缺口";

    card.innerHTML = `
      <div class="job-top">
        <span class="rank">#${index + 1}</span>
        <div>
          <h3></h3>
          <p></p>
        </div>
        <strong>${best?.score ?? "--"}</strong>
      </div>
      <div class="job-detail">
        <div><b>推荐简历</b><span>${escapeHtml(best?.resumeName || "无")}</span></div>
        <div><b>命中</b><span>${escapeHtml(matched)}</span></div>
        <div><b>缺口</b><span>${escapeHtml(missing)}</span></div>
      </div>
      <div class="job-actions">
        <a href="${escapeAttribute(job.url || "#")}" target="_blank" rel="noreferrer">打开岗位</a>
      </div>
    `;
    card.querySelector("h3").textContent = job.title || "未命名岗位";
    card.querySelector("p").textContent = meta || "当前页面";
    rankedJobs.append(card);
  }
}

function renderResumes() {
  resumeList.replaceChildren();
  if (!resumes.length) {
    resumeList.append(emptyNode("还没有简历版本"));
    return;
  }

  for (const resume of resumes) {
    const item = document.createElement("article");
    item.className = "resume-item";
    item.innerHTML = `
      <div>
        <strong></strong>
        <span>${resume.text.length} 字</span>
      </div>
      <button class="danger" data-id="${escapeAttribute(resume.id)}">删除</button>
    `;
    item.querySelector("strong").textContent = resume.name || "未命名简历";
    item.querySelector("button").addEventListener("click", async () => {
      resumes = resumes.filter((entry) => entry.id !== resume.id);
      await chrome.storage.local.set({ [STORAGE_KEYS.resumes]: resumes });
      render();
    });
    resumeList.append(item);
  }
}

function emptyNode(text) {
  const node = document.createElement("p");
  node.className = "empty";
  node.textContent = text;
  return node;
}

function normalize(value) {
  return String(value || "")
    .toLowerCase()
    .replace(/\s+/g, " ")
    .trim();
}

function setBusy(isBusy) {
  scanBtn.disabled = isBusy;
  refreshBtn.disabled = isBusy;
  saveResumeBtn.disabled = isBusy;
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function escapeAttribute(value) {
  return escapeHtml(value).replaceAll("`", "&#096;");
}
